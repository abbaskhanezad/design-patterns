<?php
interface socialNetwork{
    public function getAccessToken($username,$pass):string;
    public function sendMessage($token,$message);
}
class Facebook implements socialNetwork{
    public function getAccessToken($username,$pass):string{
      if($username=="abbas" && $pass=="123"){
          return '123456789';
      }
      return 'false';
    }

    public function sendMessage($token,$message){
        if($token != 'false'){
            echo "message sent to facebook. message is:".$message."<br>";

        }else{
            echo " token is invalid<br>";

        }
      
    }
}


class Twitter{

    public function getToken($username,$pass){
        if($username=="abbas" && $pass=="123"){
            return '123456789';
        }
        return false;
    }

    public function sendMsg($token,$message){
        if($token != 'false'){
            echo "message sent to twitter. message is:".$message."<br>";

        }else{
            echo " token is invalid<br>";

        }
    }
}

$obj=new Facebook();
$obj->sendMessage($obj->getAccessToken('abbas','123'),'hi');

class Adaper implements socialNetwork{
    protected $twitter;

    public function __construct(Twitter $twitter)
    {
        $this->twitter=$twitter;
    }

     public function getAccessToken($username,$pass):string{
      return json_encode($this->twitter->getToken($username,$pass));
      }

      public function sendMessage($token,$message){
        $this->twitter->sendMsg($token,$message);
      
     }

}


$obj=new Adaper(new Twitter);

$token=$obj->getAccessToken('abbas','123');
$obj->sendMessage($token,'hello');


