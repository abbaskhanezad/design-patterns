<?php

interface notifier{
    public function cost();
    public function service();
}

class sample implements notifier{


    public function cost(){
      return 0;
    }
    public function service(){
     return '';
    }
}

class Decorator implements notifier{

    protected $notif;
  
    public function __construct(notifier $notif)
    {
        $this->notif = $notif;
    }
    public function cost(){
      return 0;
    }
    public function service(){
     return '';
    }
}

class Email extends Decorator{
    public function cost(){
        return $this->notif->cost()+500;
      }
      public function service(){
   

       return $this->notif->service().'email';

    
      }
  
}

class Telegram extends Decorator{
    public function cost(){
        return $this->notif->cost()+600;
      }
      public function service(){
  

       return $this->notif->service().'telegram';

    
      }
  
}

$sample=new sample();


$email= new Email($sample);
echo $email->cost();
echo $email->service();
echo "<br><br>";
$telegram= new Telegram($email);
echo $telegram->cost();
echo $telegram->service();
echo "<br><br>";


