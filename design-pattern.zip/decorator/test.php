<?php

use Car as GlobalCar;
use Pride as GlobalPride;

interface Car{
    public function cost();
    public function description();
}
class Pride implements Car{
    public function cost(){
      return 120;
    }
    public function description(){
       return 'pride';
    }
}

abstract class FeatureCar implements Car{
    protected $car;

    public function __construct(Car $car)
    {
       $this->car=$car; 
    }
    abstract public function cost();
    abstract public function description();
}


class sunroff extends FeatureCar{
     public function cost(){
       return $this->car->cost()+20;
     }
     public function description(){
        return $this->car->description().' sunroff';
     }
}

class sensor extends FeatureCar{
    public function cost(){
      return $this->car->cost()+50;
    }
    public function description(){
       return $this->car->description().' sensor';
    }
}



$car=new Pride();
$sensor=new sensor($car);

$sunroff=new SunRoff($sensor);

echo $sunroff->cost();
echo '<br>';
echo  $sunroff->description();