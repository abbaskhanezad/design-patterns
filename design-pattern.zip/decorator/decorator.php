<?php

interface Car {
   public function cost();
   public function description();
}

class Pride implements Car {

   public function cost()
   {
       return 4000;
   }

   public function description()
   {
       return 'pride';
   }
}

abstract class CarFeature implements Car {
   protected $car;

   public function __construct(Car $car)
   {
       $this->car = $car;
   }

   abstract public function cost();
   abstract public function description();
}

class ZevarDar extends CarFeature {

   public function cost()
   {
       return $this->car->cost() + 500;
   }

   public function description()
   {
       return $this->car->description() . ", ZevarDar";
   }
}

class SunRoof extends CarFeature {

   public function cost()
   {
       return $this->car->cost() + 2300;
   }

   public function description()
   {
       return $this->car->description() . ", SunRoof";
   }
}


$pride = new Pride();
$pride = new SunRoof($pride);

$pride = new ZevarDar($pride);
echo $pride->cost();
echo '<br>';
echo  $pride->description();