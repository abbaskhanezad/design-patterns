<?php

interface ContexInterface
      {
          // Attach an observer to the subject.
         public function attach(SubscriberInterface $observer);
 
        // Detach an observer from the subject.
         public function detach(SubscriberInterface $observer);
 
          // Notify all observers about an event.
          public function notify();
      }

      interface SubscriberInterface
      {
          // Attach an observer to the subject.
         public function update(ContexInterface $observer);
 
 
      }


      class Context implements ContexInterface{
          private $subscribers;
          public $amount=20;
           // Attach an observer to the subject.
         public function attach( $observer){
        //    $this->subscribers->attach($observer);
        $observerKey = spl_object_hash($observer);
        $this->subscribers[$observerKey] = $observer;
           echo "subscriber attached <br>";
         }
 
         // Detach an observer from the subject.
          public function detach( $observer){
            // $this->subscribers->detach($observer);
            $observerKey = spl_object_hash($observer);
            unset($this->subscribers[$observerKey]);
            echo "subscriber detached <br>";

          }
  
           // Notify all observers about an event.
           public function notify(){
            echo "notifier runed......... <br>";
             foreach($this->subscribers as $subscriber){
                 $subscriber->update($this);
             }
           }

      }

      class Subscriber implements SubscriberInterface{
        public function update( $context){
          echo 'update run.......<br>';
          if($context->amount<40){
            echo 'yessssss.<br>';
        }else{
            echo 'noooooooooo.<br>';
        }
        }
      }

      class Subscriber2 implements SubscriberInterface{
        public function update( $context){
          echo 'update run.......<br>';
          if($context->amount>40){
              echo 'yessssss.<br>';
          }else{
              echo 'noooooooooo.<br>';
          }

        }
      }


      $context=new Context();
      $subscriber=new Subscriber();
      $context->attach($subscriber);
      $subscriber=new Subscriber();
      $context->attach($subscriber);
      $context->notify();
      $context->detach($subscriber);
      $context->notify();
      $subscriber=new Subscriber2();
      $context->attach($subscriber);
      $context->notify();
      $context->amount=60;
      $context->notify();



