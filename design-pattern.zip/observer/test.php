<?php
interface SitetInterface{
public function attach(UserInterface $user);
public function detach(UserInterface $user);
public function notify();
}

interface UserInterface{

  public function update(SitetInterface $site);
}

class Site implements SitetInterface{
    public $course_name='laravel';
    private $observers;

  public function attach(UserInterface $user){
      if($user instanceof User)
    echo 'user attached <br>';
    else
    echo 'student attached <br>';
      $this->observers[spl_object_hash($user)]=$user;

  }
  public function detach(UserInterface $user){
    if($user instanceof User)
    echo 'user detached <br>';
    else
    echo 'student detached <br>';
      unset($this->observers[spl_object_hash($user)]);
  }
  public function notify(){
    foreach($this->observers as $user){
        $user->update($this);
    }
 }

}

class User implements UserInterface{
    public function update(SitetInterface $site){
       if($site->course_name=='php'){
           echo 'i would like to register <br>';
       }else{
            echo 'i dont would like to register <br>';
       }
    }
}

class Student implements UserInterface{
    public function update(SitetInterface $site){
       if($site->course_name=='laravel'){
           echo 'i would like to register <br>';
       }else{
            echo 'i dont would like to register <br>';
       }
    }
}

$site=new Site();
$user1=new User();
$user2=new User();
$student1=new Student();
$student2=new Student();


$site->attach($user1);
$site->attach($user2);
$site->attach($student1);
 //$site->course_name="php";
$site->notify();
echo "------------<br>";

$site->detach($user1);

$site->notify();
