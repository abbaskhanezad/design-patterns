<?php

class Bulb // Receiver
{
    public function turnOn()
    {
        echo "Bulb has been lit <br>";
    }
    public function turnOff()
    {
        echo "Darkness!<br>";
    }
}

interface Command
{
    public function execute();
    public function undo();
    public function redo();
}

class Remote{  //invoker
   public function apply(Command $command){
       $command->execute();
   }



      public function rollback(Command $command){
          $command->undo();
    }
}

class simpleCammand implements Command  // Command
{

    protected $bulb;

    public function __construct(Bulb $bulb)
    {
        $this->bulb = $bulb;
    }
    public function execute()
    {
        $this->bulb->turnOn();
    }
    public function undo()
    {
        $this->bulb->turnOff();
    }
    public function redo()
    {
        $this->execute();
    }
}

class turnOff implements Command
{

    protected $bulb;

    public function __construct(Bulb $bulb)
    {
        $this->bulb = $bulb;
    }
    public function execute()
    {
        $this->bulb->turnOff();
    }
    public function undo()
    {
        $this->bulb->turnOn();
    }
    public function redo()
    {
        $this->execute();
    }
}

$bulb=new Bulb();
$command=new simpleCammand($bulb);
$turnoff=new turnOff($bulb);

$remote = new Remote();
$remote->apply($command);
$remote->rollback($command);

$remote->apply($turnoff);


